cd ..\data_raw
T = readtable('data_raw.csv');
%1a remove all missing values along with their rows/columns
%JUSTIFICATION: We want clean data that doesn't bias our model. In that
%vein removing all missing instances will number one simplify our data
%analysis and furthermore establish consistent standards
%In this way while we hvae less power, our bias is lowered. This tradeoff
%is one we're willing to accept
R = rmmissing( T ); 

Q = R;

s = '1.25ns';

%1b Remove the units

a1 = Q.Mileage;
for k = 1 : length(a1)
    cellContents = a1{k};
    % Truncate and stick back into the cell
    a1{k} = cellContents(1:end-5);
end
Q.Mileage =a1;

a2 = Q.Engine;
for k = 1 : length(a2)
    cellContents = a2{k};
    % Truncate and stick back into the cell
    a2{k} = cellContents(1:end-2);
end
Q.Engine =a2;

a3 = Q.Power;
for k = 1 : length(a3)
    cellContents = a3{k};
    % Truncate and stick back into the cell
    a3{k} = cellContents(1:end-3);
end
Q.Power =a3;

a4 = Q.New_Price;
for k = 1 : length(a4)
    cellContents = a4{k};
    % Truncate and stick back into the cell
    a4{k} = cellContents(1:end-4);
end
Q.New_Price =a4;

%1c One-hot-encoding 
FuelTypeCopy = cellstr(Q.Fuel_Type);
FuelTypeCopy(strcmpi(FuelTypeCopy,'Manual')) = {'1'}; 
FuelTypeCopy(strcmpi(FuelTypeCopy,'Automatic')) = {'0'}; 

FuelTypeCopy2 = cellstr(Q.Fuel_Type);
FuelTypeCopy2(strcmpi(FuelTypeCopy2,'Manual')) = {'0'}; 
FuelTypeCopy2(strcmpi(FuelTypeCopy2,'Automatic')) = {'1'}; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
FuelTypeCopy3 = cellstr(Q.Transmission);
FuelTypeCopy3(strcmpi(FuelTypeCopy3,'Manual')) = {'1'}; 
FuelTypeCopy3(strcmpi(FuelTypeCopy3,'Automatic')) = {'0'}; 

FuelTypeCopy4 = cellstr(Q.Transmission);
FuelTypeCopy4(strcmpi(FuelTypeCopy4,'Manual')) = {'0'}; 
FuelTypeCopy4(strcmpi(FuelTypeCopy4,'Automatic')) = {'1'};

P=Q;
fused1 = [FuelTypeCopy FuelTypeCopy2];
fused2 = [FuelTypeCopy3 FuelTypeCopy4];
P.Fuel_Type = fused1;
P.Transmission = fused2;
%%%%%%%Finished w/ one hot encoding %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%Adding final column to end of table CURRENT AGE %%%%%%%%%%%%%%%%%%%%%
P.CurrentAge = 2023*ones(814,1)- (P.Year);

writetable(R,'1a.csv')
writetable(Q,'1c.csv')
writetable(P,'1c&d.csv')

