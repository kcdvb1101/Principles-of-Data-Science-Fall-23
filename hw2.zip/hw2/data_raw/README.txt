Frailty is physical weakness; lack of health or strength. Reduced grip strength in females correlated
with higher frailty scores and vice versa. Hand grip strength can be quantified by measuring the amount
of static force that the hand can squeeze around a dynamometer. The force has most commonly been
measured in kilograms and pounds. The table below represents data from 10 female participants. The
Height is measured in inches, Weight in pounds, Age in years, Grip strength in kilograms. Frailty is
qualitative attribute indicated the presence or absence of the symptoms. Based on the following table,
design the three stages of reproducible workflow, includes the work you can do and the folder structure
in each stage (reference study case in chapter 3).


#This folder contains the raw data
#In this case the data has gaps/other problems

1) The provided data (link above) contains various details and attributes associated with used cars. The
target variable, which is the central focus of analysis, is the price of the used cars, and it is measured in
lakhs. The data in this dataset is tabular, with rows and columns, where each row represents a specific
used car listing, and each column represents a particular attribute or feature of these cars. Features are
Make and model of the car, Location or city of sale, Year of manufacture, Mileage, Odometer
(kilometers driven), Fuel type (petrol or diesel), Transmission type (manual or automatic), Number of
owners, Engine displacement, Engine horsepower, Number of seats, and Price when the car was new.