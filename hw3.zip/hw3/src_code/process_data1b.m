cd ..\data_raw
%Part 1a
T = readtable('data_raw.csv');

onebbmivec = T.BMI;
idx = randperm(768,25);
idx = idx';

%How to solve faster
sampled = onebbmivec(idx);
avg_schmuck = num2str(mean(sampled));

cdfplot(onebbmivec)
xlabel('BMI')
ylabel('Percentile/100')
titular = strcat('BMI levels per sample Mean:',avg_schmuck);
title(titular)
