cd ..\data_raw
%Part 1a
T = readtable('data_raw.csv');

oneaglucvec = T.Glucose;
idx = randperm(768,25);
idx = idx';

%How to solve faster
oneaglucvec(idx);

sampled = oneaglucvec(idx);
avg_schmuck = num2str(mean(sampled));

boxplot(sampled)
xlabel('Random sample of 25')
ylabel('Glucose levels')
titular = strcat('Glucose levels per sample Mean:',avg_schmuck);
title(titular)
