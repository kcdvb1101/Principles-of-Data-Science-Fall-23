Task is to make 5 different visualizations 

%All visualizations done in matlab 2023
% 1. Histogram of sum of all math scores --> Show the distribution, easy to see mean and check if there is skew
% 2. Scatter chart Correlation between Reading/Writing scores --> Want to show correlation exists or not
% 3. Pi-Chart of Scorers in math by Racial Group --> Want to see whether makeup is even or biased
% 4. Bubble Chart for race agnostic correlation math/reading scores -->
% Rule out possibility say international students from country X had a
% biased education
% 5. Simple swarm chart with reading score by gender--> Want to see at a
% glance if distributions of reading score by gender is significantly
% different

#This folder contains the raw data
#In this case the data is clean 
#So we concentrate on the visualization