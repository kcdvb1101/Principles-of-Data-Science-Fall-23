%Load clean data, assuming we are in the src directory
cd ..\data_clean\
T = readtable('data_clean.csv');
%All visualizations done in matlab 2023
% 1. Histogram of sum of all math scores --> Show the distribution, easy to see mean and check if there is skew
% 2. Scatter chart Correlation between Reading/Writing scores --> Want to show correlation exists or not
% 3. Pi-Chart of Scorers in math by Racial Group --> Want to see whether makeup is even or biased
% 4. Bubble Chart for race agnostic correlation math/reading scores -->
% Rule out possibility say international students from country X had a
% biased education
% 5. Simple swarm chart with reading score by gender--> Want to see at a
% glance if distributions of reading score by gender is significantly
% different


%visual 1 Math scores histogram
hist(T.mathScore)
xlabel('Math Scores')
ylabel('Count')
title('Histogram of math scores')

%visual 2 scatterplot readding/writing
scatter(T.readingScore,T.writingScore)
xlabel('Reading Scores')
ylabel('Writing Scores')
title('Investigating Correlation between Reading/Writing Scores')

%visual 3 pie chart of ethnicity
[uc, ~, idc] = unique(T.race_ethnicity) ;
counts = accumarray( idc, ones(size(idc)) ) ;
labels = {'Group A','Group B','Group C','Group D', 'Group E'};
pie(counts,labels)
title('Proprtion of all examinees by race')

%visual 4 Race agnostic bubble chart
[C,~,ib] = unique(T.race_ethnicity);
xlabel('Math Scores')
ylabel('Reading Scores')
title('Race agnostic correlation of math and reading scores')

%visual 5 Swarm chart Reading score by gender
swarmchart(ib,T.readingScore)
xlabel('Gender Male 1 Female 2')
ylabel('Reading Scores')
title('Swarm chart to visualize distributions not just means')