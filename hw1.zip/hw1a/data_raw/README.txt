Frailty is physical weakness; lack of health or strength. Reduced grip strength in females correlated
with higher frailty scores and vice versa. Hand grip strength can be quantified by measuring the amount
of static force that the hand can squeeze around a dynamometer. The force has most commonly been
measured in kilograms and pounds. The table below represents data from 10 female participants. The
Height is measured in inches, Weight in pounds, Age in years, Grip strength in kilograms. Frailty is
qualitative attribute indicated the presence or absence of the symptoms. Based on the following table,
design the three stages of reproducible workflow, includes the work you can do and the folder structure
in each stage (reference study case in chapter 3).


#This folder contains the raw data
#In this case the data is mostly clean already but we will do
#a sample cleaning e.g. replace Y/N with 'Yes', & 'No'