%Load clean data, assuming we are in the src directory
cd ..\data_clean\
T = readtable('data_clean.csv');

%Since there is not enough data to do real analysis
%We will just plot two box and whisker plots
%to see if there is a difference at least visually

boxplot(T.GripStrength,T.Frailty)