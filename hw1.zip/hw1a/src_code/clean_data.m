cd ..\data_raw
T = readtable('data_raw.csv');
%Replacing to show cleanup
T.Frailty(strcmpi(T.Frailty,'Y')) = {'Yes'}; 
T.Frailty(strcmpi(T.Frailty,'N')) = {'No'}; 
%Writing output csv
cd ../data_clean
writetable(T,'data_clean.csv')
